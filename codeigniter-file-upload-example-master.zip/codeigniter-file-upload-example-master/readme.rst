###################
CodeIgniter File Upload Example
###################

URL:  `http://programmerblog.net/`

1. Create a upload.php file inside Views folder

2. Create success.php file inside Views.

3. Create Upload.php inside Controller folder.

4. Create a folder Uploads in project folder.

4. Upload an image file, validate it and save it to a directory on server.


Read detailed tutorial at 

`http://programmerblog.net/codeigniter-file-upload-example/`.
